﻿using MeetingPractice.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace MeetingPractice.Controllers
{
    public class CustsController : Controller
    {
        // GET: CustsController
        public ActionResult Index(int id)
        {
            //List<Cust> custs = Cust.GetAllCustomers();
            return View();
        }

        // GET: CustsController/Details/5
        public ActionResult Details()
        {
            return View();
        }

        // GET: CustsController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: CustsController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: CustsController/Edit/5
        public ActionResult Edit(int id)
        {
            Cust c = Cust.GetCustById(id);
            return View(c);
        }

        // POST: CustsController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, Cust collection)
        {
            try
            {
                bool updated = Cust.UpdateCust(id, collection);
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: CustsController/Delete/5
        public ActionResult Delete(int id)
        {
            Cust c = Cust.GetCustById(id);
            return View(c);
        }

        // POST: CustsController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, Cust collection)
        {
            try
            {
                bool deleted = Cust.DeleteCust(id);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(Cust c)
        {
            Cust cust = Cust.GetCustByUserAndPassword(c);
            TempData["id"] = cust.eid;
            TempData["name"] = cust.name;
            if (cust != null)
            {
            return RedirectToAction("Index");
            }
            else
            {
                return View();
            }
        }
    }
}
