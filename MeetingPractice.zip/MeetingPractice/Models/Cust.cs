﻿using Microsoft.Data.SqlClient;
using System.ComponentModel.DataAnnotations;

namespace MeetingPractice.Models
{
    public class Cust
    {
        public int eid { get; set; }
        public string name { get; set; }
        public string email { get; set; }
        public string password { get; set; }
        public string phone { get; set; }
        public string username { get; set; }
        public string gender { get; set; }
        public int city { get; set; }

        private static SqlConnection Connect()
        {
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=IACSD24;Integrated Security=True;";
            try
            {
                conn.Open();
                return conn;
            }
            catch (Exception)
            {
                throw;
            }
        }
        public static Cust GetCustByUserAndPassword(Cust c)
        {
            string sql = "select * from Cust where Username=@user and Password = @pass";
            SqlConnection conn = Connect();
            try
            {
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@user", c.username);
                cmd.Parameters.AddWithValue("@pass", c.password);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    return new Cust() { eid = (int)dr["Eid"], name = dr["Name"].ToString(), email = dr["Email"].ToString(), password = dr["Password"].ToString(), phone = dr["Phone"].ToString(), username = dr["Username"].ToString(), gender = dr["Gender"].ToString(), city = (int)dr["CityId"] };
                }
                else
                {
                    return null;
                }
            }
            catch(Exception)
            {
                throw;
            }
            finally
            {
                conn.Close();
            }
        }


        public static List<Cust> GetAllCustomers()
        {
            List<Cust> cust = new List<Cust>();
            string sql = "select * from Cust";
            SqlConnection conn = Connect();
            try
            {
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    cust.Add( new Cust() { eid = (int)dr["Eid"], name = dr["Name"].ToString(), email = dr["Email"].ToString(), password = dr["Password"].ToString(), phone = dr["Phone"].ToString(), username = dr["Username"].ToString(), gender = dr["Gender"].ToString(), city = (int)dr["CityId"] });
                }
                return cust;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conn.Close();
            }
        }

        public static Cust GetCustById(int id)
        {
            string sql = "select * from Cust where Eid = @id";
            SqlConnection conn = Connect();
            try
            {
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@id", id);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    return new Cust() { eid = (int)dr["Eid"], name = dr["Name"].ToString(), email = dr["Email"].ToString(), password = dr["Password"].ToString(), phone = dr["Phone"].ToString(), username = dr["Username"].ToString(), gender = dr["Gender"].ToString(), city = (int)dr["CityId"] };
                }
                else
                {
                    return null;
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conn.Close();
            }
        }

        public static bool UpdateCust(int id, Cust c)
        {
            string sql = "update Cust set Name= @name, Email =@email, Password = @pass, Phone=@phone, Username = @user, Gender=@gender, CityId= @cid where Eid = @id";
            SqlConnection conn = Connect();
            try
            {
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@user", c.username);
                cmd.Parameters.AddWithValue("@name", c.name);
                cmd.Parameters.AddWithValue("@email", c.email);
                cmd.Parameters.AddWithValue("@phone", c.phone);
                cmd.Parameters.AddWithValue("@gender", c.gender);
                cmd.Parameters.AddWithValue("@pass", c.password);
                cmd.Parameters.AddWithValue("@cid", c.city);
                cmd.Parameters.AddWithValue("@id", c.eid);
                if (cmd.ExecuteNonQuery() > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conn.Close();
            }
        }

        public static bool DeleteCust(int id)
        {
            string sql = "delete from Cust where Eid = @id";
            SqlConnection conn = Connect();
            try
            {
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@id", id);
                if (cmd.ExecuteNonQuery() > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conn.Close();
            }
        }
    }

}
