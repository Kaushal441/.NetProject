public class Main {
    public static void main(String[] args) {
        Graph g = new Graph(9);
        g.init();

        g.bfs(0);
        g.bfs(5);

        g.display();
        g.dfs(0);
        g.dfs(5);

        System.out.println("DFS: ");
        g.dfs(0, new boolean[g.getNoOfVertices()]);
        System.out.println();
    }
}
