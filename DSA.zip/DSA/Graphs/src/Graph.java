import java.util.LinkedList;
import java.util.Scanner;
import java.util.Stack;

public class Graph {
    private int noOfVertices;
    private char [] vertices;
    private int [][] adjMat;

    public Graph(int noOfVertices) {
        this.noOfVertices = noOfVertices;
        vertices = new char[noOfVertices];
        adjMat = new int[noOfVertices][noOfVertices];
    }

    public int getNoOfVertices() {
        return noOfVertices;
    }

    public void init() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the vertices");
        for(int i = 0; i < noOfVertices; i++) {
            //vertices[i] = scanner.nextLine().charAt(0);
            vertices[i] = (char)(65 + i);
        }

        int [] input = {0,1,1,0,0,0,0,0,0,1,0,0,1,1,0,0,0,0,1,0,0,0,1,0,0,0,0,0,1,0,0,0,1,1,0,0,0,1,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,1,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,0,0,0};
        int k = 0;


        for(int i = 0; i < noOfVertices; i++) {
            for(int j = 0; j < noOfVertices; j++) {
                //System.out.println("Edge between " + vertices[i] + " - " + vertices[j] + ": ");
                //adjMat[i][j] = scanner.nextInt();
                adjMat[i][j] = input[k++];
            }
        }
    }

    public void display() {
        System.out.println();
        System.out.print("  ");
        for(int i = 0; i < noOfVertices; i++) {
            System.out.print(vertices[i] + " ");
        }
        System.out.println();

        for(int i = 0; i < noOfVertices; i++) {
            System.out.print(vertices[i] + " ");
            for(int j = 0; j < noOfVertices; j++) {
                System.out.print(adjMat[i][j] + " ");
            }
            System.out.println();
        }
    }

    public void dfs(int v) {
        boolean [] visited = new boolean[noOfVertices];
        Stack<Integer> stack = new Stack<>();

        System.out.println("DFS: ");

        System.out.print(vertices[v] + " ");
        visited[v] = true;
        stack.push(v);

        //v is holding the index of the vertex of top of the stack
        while (!stack.isEmpty()) {
            //get the stack top
            v = stack.peek();
            //find unvisited adjacent to the vth vertex
            for(int i = 0; i < noOfVertices; i++) {
                if(adjMat[v][i] == 1 && visited[i] == false) {
                    System.out.print(vertices[i] + " ");
                    visited[i] = true;
                    stack.push(i);
                    //i is on top of the stack, so v = i makes sure that v is holding the vertex on top of the stack
                    v = i;
                    //reset i back to 0
                    i = -1;
                }
            }

            stack.pop();
        }
        System.out.println();
    }

    public void dfs(int v, boolean [] visited) {
        if(visited[v] == true) {
            return;
        }

        System.out.print(vertices[v] + " ");
        visited[v] = true;

        for(int i = 0; i < noOfVertices; i++) {
            if(adjMat[v][i] == 1) {
                dfs(i, visited);
            }
        }
    }

    public void bfs(int v) {
        LinkedList<Integer> q = new LinkedList<>();
        boolean [] visited = new boolean[noOfVertices];

        q.addLast(v);

        System.out.println("BFS: ");

        while(!q.isEmpty()) {
            v = q.removeFirst();
            if(!visited[v]) {
                System.out.print(vertices[v] + " ");
                visited[v] = true;
                for(int i = 0; i < noOfVertices; i++) {
                    if(adjMat[v][i] == 1 && visited[i] == false) {
                        q.addLast(i);
                    }
                }
            }
        }
        System.out.println();
    }
}




