public class Main {
    public static void main(String[] args) {
         Stack<Integer> s = new Stack<>(5);

        System.out.println(s.push(10));
        System.out.println(s.pop());
    }
}
