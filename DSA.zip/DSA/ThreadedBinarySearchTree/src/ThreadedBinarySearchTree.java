public class ThreadedBinarySearchTree {
    private Node root;

    public ThreadedBinarySearchTree() {
        root = null;
    }

    public boolean insert(int data) {
        Node newNode = new Node(data);
        if (newNode == null) {
            return false;
        }

        if (root == null) {
            root = newNode;
            return true;
        }

        Node temp = root;

        while (true) {
            if (data == temp.getData()) {
                return false;
            }
            if (data < temp.getData()) {
                if (temp.getlFlag() == 'T') {
                    //insert newNode to the left
                    newNode.setRight(temp);
                    newNode.setLeft(temp.getLeft());

                    temp.setLeft(newNode);
                    temp.setlFlag('L');
                    return true;
                }
                //temp already has a left child, so shift the temp to it's left
                temp = temp.getLeft();
            } else {
                if (temp.getrFlag() == 'T') {
                    //insert newNode to the right
                    newNode.setLeft(temp);
                    newNode.setRight(temp.getRight());

                    temp.setRight(newNode);
                    temp.setrFlag('L');

                    return true;
                }
                temp = temp.getRight();
            }
        }

    }

    public boolean delete(int data) {
        if (root == null) {
            return false;
        }

        //locate the del node along with the parent node
        Node parent = root, del = root;
        while (del.getData() != data) {
            parent = del;
            if (data < del.getData()) {
                if (del.getlFlag() == 'L') {
                    del = del.getLeft();
                } else {
                    return false;
                }
            } else {
                if (del.getrFlag() == 'L') {
                    del = del.getRight();
                } else {
                    return false;
                }
            }
        }

        while (true) {
            //check if the del node is a terminal node or not
            if (del.getlFlag() == 'T' && del.getrFlag() == 'T') {

                //check if the del node is root node
                if (del == root) {
                    root = null;
                    return true;
                }

                //check if the del is left or right child of the parent
                if (parent.getLeft() == del) {
                    //del's inorder predecessor will become inorder predecessor of parent
                    parent.setLeft(del.getLeft());
                    parent.setlFlag('T');

                } else {
                    parent.setRight(del.getRight());
                    parent.setrFlag('T');
                }
                return true;
            }

            //del is a non terminal node
            if (del.getlFlag() == 'L') {
                //find max from left subtree, also make sure that the parent is following max
                Node max = del.getLeft();
                parent = del;
                while (max.getrFlag() == 'L') {
                    parent = max;
                    max = max.getRight();
                }

                //Swap the del and max's data
                int temp = del.getData();
                del.setData(max.getData());
                max.setData(temp);

                //max is the node to be deleted
                del = max;
            } else {
                //find min from right subtree, also make sure that the parent is following min
                Node min = del.getRight();
                parent = del;

                while (min.getlFlag() == 'L') {
                    parent = min;
                    min = min.getLeft();
                }

                //swap min with del
                int temp = del.getData();
                del.setData(min.getData());
                min.setData(temp);

                del = min;
            }
        }
    }

    public void preOrder() {
        Node temp = root;
        char flag = 'L';

        System.out.println("Preorder: ");
        while (temp != null) {

            while (temp.getlFlag() == 'L' && flag == 'L') {
                System.out.print(temp.getData() + " ");
                temp = temp.getLeft();
            }
            if (flag == 'L') {
                System.out.print(temp.getData() + " ");
            }

            flag = temp.getrFlag();
            temp = temp.getRight();
        }
        System.out.println();
    }

    public void inOrder() {
        Node temp = root;
        char flag = 'L';

        System.out.println("Inorder: ");
        while (temp != null) {

            while (temp.getlFlag() == 'L' && flag == 'L') {
                temp = temp.getLeft();
            }

            System.out.print(temp.getData() + " ");

            flag = temp.getrFlag();
            temp = temp.getRight();
        }
        System.out.println();
    }

    public void postOrder() {
        Node temp = root;
        char flag = 'L';

        System.out.println("Postorder: ");

        while (temp != null) {
            while (temp.getlFlag() == 'L' && flag == 'L') {
                temp = temp.getLeft();
            }

            flag = temp.getrFlag();

            if (flag == 'L') {
                temp = temp.getRight();
            } else {
                while(true) {
                    System.out.print(temp.getData() + " ");
                    if (isRightChild(temp)) {
                        //locate the parent of temp
                        while (temp.getlFlag() == 'L') {
                            temp = temp.getLeft();
                        }
                        temp = temp.getLeft();
                    } else {
                        while(temp.getrFlag() == 'L') {
                            temp = temp.getRight();
                        }
                        temp = temp.getRight();
                        break;
                    }
                }
            }
        }
        System.out.println();
    }

    private boolean isRightChild(Node temp) {
        if(temp == root) {
            return false;
        }

        Node node = root;
        while(true) {
            if (temp.getData() < node.getData()) {
                node = node.getLeft();
                if (temp == node) {
                    return false;
                }
            } else {
                node = node.getRight();
                if (temp == node) {
                    return true;
                }
            }
        }
    }
}
