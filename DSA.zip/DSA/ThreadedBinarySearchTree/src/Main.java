public class Main {
    public static void main(String[] args) {
        ThreadedBinarySearchTree bst = new ThreadedBinarySearchTree();


        bst.preOrder();

        bst.insert(50);
        bst.insert(20);
        bst.insert(90);
        bst.insert(10);
        bst.insert(15);
        bst.insert(30);
        bst.insert(25);
        bst.insert(80);
        bst.insert(60);
        bst.insert(85);
        bst.insert(100);

        bst.preOrder();
        bst.inOrder();
        bst.postOrder();
        bst.delete(50);
        bst.preOrder();
        bst.inOrder();
        bst.postOrder();

    }
}
