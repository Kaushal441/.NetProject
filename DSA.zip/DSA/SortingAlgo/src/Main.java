public class Main {
    public static void main(String[] args) {
        int [] arr = {12, 50, 34, 9, 42, 80, 44, 67, 89};

        /*int passes = Util.bubbleSort(arr);
        System.out.println("passes: " + passes);*/

        //Util.selectionSort(arr);
        //Util.insertionSort(arr);

        //Util.quickSort(arr, 0, arr.length-1);
        //Util.mergeSort(arr, 0, arr.length-1);
        Util.heapSort(arr, arr.length);

        for(int val:  arr) {
            System.out.print(val + " ");
        }
        System.out.println();
    }
}
