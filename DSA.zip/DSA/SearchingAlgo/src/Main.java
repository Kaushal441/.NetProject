public class Main {
    public static void main(String[] args) {
        int[] arr = {10, 20, 30, 40, 50, 60, 70, 80, 90, 100};
        System.out.println("10: " + Util.binarySearch(arr, 10));
        System.out.println("60: " + Util.binarySearch(arr, 60));
        System.out.println("100: " + Util.binarySearch(arr, 100));
        System.out.println("90: " + Util.binarySearch(arr, 90));
        System.out.println("12: " + Util.binarySearch(arr, 12));


        System.out.println("10: " + Util.binarySearch(arr, 0, arr.length - 1, 10));
        System.out.println("60: " + Util.binarySearch(arr, 0, arr.length - 1, 60));
        System.out.println("100: " + Util.binarySearch(arr, 0, arr.length - 1, 100));
        System.out.println("90: " + Util.binarySearch(arr, 0, arr.length - 1, 90));
        System.out.println("12: " + Util.binarySearch(arr, 0, arr.length - 1, 12));
    }
}
